=== { WP BootWeb } ===
Hak cipta 2017, WP BootWeb oleh Tim Pengembang Ngawi Cloud.

Alhamdulillah, all praise to be Allah the king of the world. We the The Ngawi Cloud Developers Team can finish the wordpress themes in month December 2017. It's to be our pride to us, because this theme is first theme was we create. Okay, then we want to display the details of this theme.

Theme name: WP BootWeb
The theme creator: The Team Ngawi Cloud Developers
Relase date: Thursday, 06th December 2017

Changelog:
1. Version 1.0-beta
   - Creating Theme
   - Fix bug
   - change the #masthead section
2. Version 1.0
   - Change color theme to flat design color.
   - fix the translation
   - add one css design