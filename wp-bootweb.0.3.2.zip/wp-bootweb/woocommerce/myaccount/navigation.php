<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_account_navigation' );
?>
<div class="mb-3">  
<div class="list-group text-black">
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
				<a class="list-group-item text-dark border-0" href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>"><?php echo esc_html( $label ); ?></a>
				<?php endforeach; ?>
	</div>
</div>

<div class="card bg-secondary text-white mb-3">
  <div class="card-header bg-white text-secondary"><?php echo __('Want To Buy Again?', 'bootweb'); ?></div>
  <div class="card-body"><?php echo __('Are you want to buy other item? Let&rsquo;s to follow this link.', 'bootweb'); ?></div><a href="/shop" class="card-footer bg-white text-secondary"><?php echo __('Click Here', 'bootweb'); ?> <span class="fa fa-arrow-right float-right"></span></a>
</div>

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
