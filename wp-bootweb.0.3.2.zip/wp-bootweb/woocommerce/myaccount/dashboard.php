<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/dashboard.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @author      WooThemes
 * @package     WooCommerce/Templates
 * @version     2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>

<div class="mb-3 row" id="account-shortcut">
  <div class="col-md-3 mb-3">
    <div class="card bg-primary text-white">
       <div class="card-body">
          <div class="text-center"><i class="fa fa-shopping-cart fa-fw fa-3x"></i></div>
          <div class="text-center"><?php printf( __( 'All of your history orders.', 'bootweb' ) ); ?></div>
      </div>
      <a class="card-footer text-primary bg-white" href="">
        <span class="float-left"><?php printf( __( 'Look All', 'bootweb' ) ); ?></span>
        <span class="float-right">
          <i class="fa fa-arrow-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="col-md-3 mb-3">
     <div class="card border-danger bg-danger">
        <div class="card-body text-white">
           <div class="text-center"><i class="fa fa-ticket fa-3x"></i></div>
           <div class="text-center">Tiket Dukungan dan Pertanyaan.</div>
        </div>
        <a class="card-footer text-danger bg-white" href="">
          <span class="float-left">Lihat Semua</span>
          <span class="float-right"><i class="fa fa-arrow-right"></i></span>
        </a>
     </div>
   </div>
   <div class="col-md-3 mb-3">
      <div class="card bg-warning text-white">
         <div class="card-body">
            <div class="text-center"><i class="fa fa-download fa-3x"></i></div>
            <div class="text-center">Semua Produk Unduhan.</div>
         </div>
         <a href="" class="text-warning bg-white card-footer">
            <span class="text-left">Lihat Semua</span>
            <span class="text-right"><i class="fa fa-arrow-right"></i></span>
         </a>
      </div>
   </div>
   <div class="col-md-3 mb-3">
     <div class="card bg-success">
        <div class="card-body text-white">
           <div class="text-center"><i class="fa fa-bookmark-o fa-3x"></i></div>
           <div class="text-center">Pengetahuan dan Panduan Dasar Penggunaan.</div>
        </div>
        <a href="" class="text-success bg-white card-footer">
           <span class="float-left">Baca Semua</span>
           <span class="float-right"><i class="fa fa-arrow-right"></i></span>
        </a>
     </div>
   </div>
</div>
<p><?php
	/* translators: 1: user display name 2: logout url */
	printf(
		__( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ),
		'<strong>' . esc_html( $current_user->display_name ) . '</strong>',
		esc_url( wc_logout_url( wc_get_page_permalink( 'myaccount' ) ) )
	);
?></p>

<p><?php
	printf(
		__( 'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a> and <a href="%3$s">edit your password and account details</a>.', 'woocommerce' ),
		esc_url( wc_get_endpoint_url( 'orders' ) ),
		esc_url( wc_get_endpoint_url( 'edit-address' ) ),
		esc_url( wc_get_endpoint_url( 'edit-account' ) )
	);
?></p>

<?php
	/**
	 * My Account dashboard.
	 *
	 * @since 2.6.0
	 */
	do_action( 'woocommerce_account_dashboard' );

	/**
	 * Deprecated woocommerce_before_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_before_my_account' );

	/**
	 * Deprecated woocommerce_after_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_after_my_account' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
